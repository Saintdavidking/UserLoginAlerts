module.exports = ({ env }) => ({
  email: {
    config: {
      provider: 'nodemailer',
      providerOptions: {
        host: env('EMAIL_SMTP_HOST', 'smtp.gmail.com'),
        port: env.int('EMAIL_SMTP_PORT', 587),
        secure: false,        // use STARTTLS, not SMTPS
        requireTLS: true,     // force TLS upgrade
        auth: {
          user: env('EMAIL_SMTP_USER'),
          pass: env('EMAIL_SMTP_PASS'),
        },
        connectionTimeout: 15000,
        greetingTimeout: 10000,
        socketTimeout: 20000,
      },
      settings: {
        defaultFrom: env('EMAIL_DEFAULT_FROM', env('EMAIL_SMTP_USER')),
        defaultReplyTo: env('EMAIL_DEFAULT_REPLY_TO', env('EMAIL_SMTP_USER')),
      },
    },
  },
});
