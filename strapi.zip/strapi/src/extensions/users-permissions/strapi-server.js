'use strict';

const geoip = require('geoip-lite');
const twilio = require('twilio');

module.exports = (plugin) => {
  const originalCallback = plugin.controllers.auth.callback;

  plugin.controllers.auth.callback = async (ctx) => {
    // Run original login flow
    await originalCallback(ctx);

    try {
      // If login succeeded, ctx.body should contain { jwt, user }
      const body = ctx.body || ctx.response?.body;
      if (!body || !body.user) return;

      const user = body.user;
      const userEmail = user.email;
      // Best-effort IP extraction
      const xff = ctx.request.headers['x-forwarded-for'];
      const rawIp = (Array.isArray(xff) ? xff[0] : (xff || '')).split(',')[0].trim() || ctx.request.ip || ctx.ip || '0.0.0.0';

      const geo = geoip.lookup(rawIp) || {};
      const locationStr = geo && (geo.city || geo.region || geo.country)
        ? `${geo.city || ''}${geo.city ? ', ' : ''}${geo.region || ''}${(geo.city || geo.region) ? ', ' : ''}${geo.country || ''}`
        : 'Unknown';

      const alertRecipientEmail = process.env.ALERT_RECIPIENT_EMAIL;

      const lines = [
        `User Login Alert`,
        `-----------------`,
        `User: ${userEmail}`,
        `IP: ${rawIp}`,
        `Location: ${locationStr}`,
        `Timestamp: ${new Date().toISOString()}`
      ];
      const textBody = lines.join('\n');

      // Send Email via Strapi email plugin
      if (alertRecipientEmail) {
        try {
          await strapi.plugin('email').service('email').send({
            to: alertRecipientEmail,
            subject: 'Login Alert',
            text: textBody,
          });
        } catch (e) {
          strapi.log.error('Failed to send alert email:', e);
        }
      } else {
        strapi.log.warn('ALERT_RECIPIENT_EMAIL not set; skipping email alert.');
      }

      // Send SMS via Twilio if configured
      const sid = process.env.TWILIO_ACCOUNT_SID;
      const token = process.env.TWILIO_AUTH_TOKEN;
      const from = process.env.TWILIO_FROM;
      const to = process.env.ALERT_RECIPIENT_PHONE;

      if (sid && token && from && to) {
        try {
          const client = twilio(sid, token);
          await client.messages.create({
            from,
            to,
            body: textBody,
          });
        } catch (e) {
          strapi.log.error('Failed to send alert SMS:', e);
        }
      } else {
        strapi.log.warn('Twilio env vars missing; skipping SMS alert.');
      }
    } catch (err) {
      strapi.log.error('Login alert hook error:', err);
    }
  };

  return plugin;
};
